// client/src/App.tsx

import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';
import axios from 'axios';
import { ChartOptions } from 'chart.js'; // Import Chart.js types
import { ChartDataDocument } from 'C:/Users/HP/live-data-charts-app/models/ChartData'; // Import the correct ChartDataDocument type

const App: React.FC = () => {
  const [data, setData] = useState<ChartDataDocument[]>([]);

  useEffect(() => {
    // Fetch data from the server
    axios.get<ChartDataDocument[]>('/api/data').then((response) => {
      setData(response.data);
    });
  }, []);

  const chartData = {
    labels: data.map((item) => item.x.toString()),
    datasets: [
      {
        label: 'Live Data Chart',
        data: data.map((item) => item.y),
        backgroundColor: 'rgba(75,192,192,0.4)',
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 2,
      },
    ],
  };

  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        type: 'linear',
        position: 'bottom',
      },
    },
  };

  return (
    <div className="App">
      <h1>Live Data Chart</h1>
      <div style={{ width: '80%', margin: '0 auto' }}>
        <Line data={chartData} options={chartOptions} />
      </div>
    </div>
  );
};

export default App;
